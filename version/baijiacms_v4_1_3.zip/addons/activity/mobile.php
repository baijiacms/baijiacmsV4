<?php
defined('SYSTEM_IN') or exit('Access Denied');
class activityAddons  extends BjModule {

		public function do_index() {
				
					$this->__mobile(__FUNCTION__);
			}
					public function do_join() {
				
					$this->__mobile(__FUNCTION__);
			}
}


