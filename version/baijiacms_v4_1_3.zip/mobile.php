<?php
define('SYSTEM_ACT', 'mobile');
require "index.php";
