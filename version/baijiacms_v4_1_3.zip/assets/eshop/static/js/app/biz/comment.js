/*
 * 人人商城
 * 
 * QQ:834633039
 */
define(['jquery','core'], function($){
    var comment = {
         currentpage: 0, //当前页
         pagesize: 10 //每页记录数
    };
    
    //获取评论
    comment.get = function(){
        
        
        
    }
    
    //发表评论
    comment.post = function(){
        
    }
    
    
    
});

